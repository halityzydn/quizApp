using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Text.Json.Nodes;

namespace Quiz_App_Multi_Choice
{
    public partial class Form1 : Form
    {
        private string[] choices = new string[4];
        private Random rand = new Random();
        string site = "https://opentdb.com/api.php?amount=50&category=22&type=multiple";
        string correctAnswer, wrongAnswer1, wrongAnswer2, wrongAnswer3, question, questionTranslation, correctAnswerTranslation, wrongAnswerTranslation1, wrongAnswerTranslation2, wrongAnswerTranslation3;
        int random;
        JArray questions;
        JObject jsonQuestionTranslate, jsonCorrectAnswerTranslate, jsonWrongAnswerTranslate1, jsonWrongAnswerTranslate2, jsonWrongAnswerTranslate3;

        public Form1()
        {
            InitializeComponent();
            this.Load += async (s, e) => await FetchTheQuestion();
        }

        private async Task<string> TranslateText(string text)
        {
            using (HttpClient client = new HttpClient())
            {
                string translateUrl = $"https://lingva.ml/api/v1/en/de/{Uri.EscapeDataString(text)}";
                HttpResponseMessage response = await client.GetAsync(translateUrl);

                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    JObject jsonTranslation = JObject.Parse(data);
                    return jsonTranslation["translation"]?.ToString();
                }
                else
                {
                    return text; // Fallback to original text if translation fails
                }
            }
        }

        private async Task FetchTheQuestion()
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(site);

                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    JObject json = JObject.Parse(data);

                    questions = (JArray)json["results"];
                    random = new Random().Next(0, questions.Count);

                    question = WebUtility.HtmlDecode(questions[random]["question"].ToString());
                    correctAnswer = WebUtility.HtmlDecode(questions[random]["correct_answer"].ToString());
                    wrongAnswer1 = WebUtility.HtmlDecode(questions[random]["incorrect_answers"][0].ToString());
                    wrongAnswer2 = WebUtility.HtmlDecode(questions[random]["incorrect_answers"][1].ToString());
                    wrongAnswer3 = WebUtility.HtmlDecode(questions[random]["incorrect_answers"][2].ToString());

                    var questionTask = TranslateText(question);

                    await Task.WhenAll(questionTask);

                    // Use the translation helper function
                    questionTranslation = questionTask.Result;

                    textBox1.Text = questionTranslation;
                    printTheChoices();
                }
                else
                {
                    textBox1.Text = "Request Failed!";
                }
            }
        }


        private async void printTheChoices()
        {
            var correctAnswerTask = TranslateText(correctAnswer);
            var wrongAnswer1Task = TranslateText(wrongAnswer1);
            var wrongAnswer2Task = TranslateText(wrongAnswer2);
            var wrongAnswer3Task = TranslateText(wrongAnswer3);

            await Task.WhenAll(correctAnswerTask, wrongAnswer1Task, wrongAnswer2Task, wrongAnswer3Task);
            
            correctAnswerTranslation = correctAnswerTask.Result;
            wrongAnswerTranslation1 = wrongAnswer1Task.Result;
            wrongAnswerTranslation2 = wrongAnswer2Task.Result;
            wrongAnswerTranslation3 = wrongAnswer3Task.Result;

            choices[0] = correctAnswerTranslation;
            choices[1] = wrongAnswerTranslation1;
            choices[2] = wrongAnswerTranslation2;
            choices[3] = wrongAnswerTranslation3;

            Random order = new Random();
            choices = choices.OrderBy(x => order.Next()).ToArray();

            textBox2.Text = choices[0];
            textBox3.Text = choices[1];
            textBox4.Text = choices[2];
            textBox5.Text = choices[3];
        }

        private async void checkTheAnswer()
        {
            if (radioButton1.Checked && textBox2.Text == correctAnswerTranslation || radioButton2.Checked && textBox3.Text == correctAnswerTranslation || radioButton3.Checked && textBox4.Text == correctAnswerTranslation || radioButton4.Checked && textBox5.Text == correctAnswerTranslation)
            {
                label6.Text = "Your answer is correct!";
                for (int i = 5; i > 0; i--)
                {
                    label1.Text = $"New question in {i} seconds";
                    await Task.Delay(1000);
                }
                newQuestion();

            }
            else
            {
                label6.Text = "Your answer is wrong! The correct answer is: " + correctAnswer;

                for (int i = 5; i > 0; i--)
                {
                    label1.Text = $"New question in {i} seconds";
                    await Task.Delay(1000);
                }
                newQuestion();

            }
        }

        private async void newQuestion()
        {
            label6.Text = "Please wait.";

            random = new Random().Next(0, questions.Count);

            question = WebUtility.HtmlDecode(questions[random]["question"].ToString());
            correctAnswer = WebUtility.HtmlDecode(questions[random]["correct_answer"].ToString());
            wrongAnswer1 = WebUtility.HtmlDecode(questions[random]["incorrect_answers"][0].ToString());
            wrongAnswer2 = WebUtility.HtmlDecode(questions[random]["incorrect_answers"][1].ToString());
            wrongAnswer3 = WebUtility.HtmlDecode(questions[random]["incorrect_answers"][2].ToString());

            // Use the translation helper function
            questionTranslation = await TranslateText(question);
            correctAnswerTranslation = await TranslateText(correctAnswer);
            wrongAnswerTranslation1 = await TranslateText(wrongAnswer1);
            wrongAnswerTranslation2 = await TranslateText(wrongAnswer2);
            wrongAnswerTranslation3 = await TranslateText(wrongAnswer3);

            textBox1.Text = questionTranslation;
            label6.Text = "";
            label1.Text = "";

            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;

            label6.Text = "";

            printTheChoices();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            checkTheAnswer();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            newQuestion();
        }
        private void textBox2_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }
        private void textBox3_Click(object sender, EventArgs e)
        {
            radioButton2.Checked = true;
        }
        private void textBox4_Click(object sender, EventArgs e)
        {
            radioButton3.Checked = true;
        }
        private void textBox5_Click(object sender, EventArgs e)
        {
            radioButton4.Checked = true;
        }
    }
}
